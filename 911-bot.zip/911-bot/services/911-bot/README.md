# 911-bot

A small Node.js Discord bot with slash commands for checking connectivity,
runtime status, managing server membership, and welcoming new members.

## Commands

- `/ping` — check whether the bot is online
- `/status` — view uptime and gateway latency
- `/help` — show the available commands
- `/setup-verify` — post the rules embed and verification button
- `/setup-ticket` — create the support ticket panel
- `/games` — show the interactive Discord games panel
- `/points` — show a player's game points
- `/leaderboard` — show the top game players

## Automatic member role

When a new member joins, the bot finds the `MEMBER` role and assigns it
automatically. If the role does not exist, the bot creates it first. The
`/setup-verify` command remains available for servers that also want a manual
rules-and-verification message.

## Automatic welcome message

When a new member joins, the bot looks for the existing
`👋-𝐖𝐄𝐋𝐂𝐎𝐌𝐄` text channel and sends an Arabic welcome embed that mentions the
member. If the channel does not exist, the bot logs that it is unavailable and
does not create a replacement channel.

## Support tickets

Run `/setup-ticket` to create the `🎫・𝑻𝑰𝑪𝑲𝑬𝑻` panel. Members can open one
private support ticket at a time. Ticket channels are visible to the ticket
creator, the existing `STAFF` role, or the automatically created
`🛡️・𝑺𝑻𝑨𝑭𝑭` role. Closing a ticket locks the creator and deletes the channel
after 10 seconds.

The department selector routes tickets to these roles:

- Support → `🛠️ 𝑺𝒖𝒑𝒑𝒐𝒓𝒕 𝑻𝒆𝒂𝒎`
- Administration → `👮 𝑴𝒐𝒅𝒆𝒓𝒂𝒕𝒐𝒓`
- Senior Administration → `👑 𝑺𝒆𝒏𝒊𝒐𝒓 𝑴𝒐𝒅`
- Complaint / Report → `🚨 𝑪𝒐𝒎𝒑𝒍𝒂𝒊𝒏𝒕 𝑻𝒆𝒂𝒎`
- Suggestion → `💡 𝑺𝒖𝒈𝒈𝒆𝒔𝒕𝒊𝒐𝒏 𝑻𝒆𝒂𝒎`

These department roles and `👑 𝑨𝒅𝒎𝒊𝒏` are created automatically when the
bot connects or when `/setup-ticket` is used. Server members with Discord
Administrator permission and the Admin role can see all tickets.

## Discord games

The games system starts automatically when the bot connects. It creates the
`🎮 𝑮𝒂𝒎𝒆 𝑴𝒂𝒔𝒕𝒆𝒓` role, the `🎮・ألعاب-ديسكورد` category, and these channels
when they do not already exist:

- `💬・دردشة-الألعاب`
- `🎮・لعب-معنا`
- `🏆・تحديات-الألعاب`
- `📊・نتائج-الألعاب`
- `🤖・أوامر-الألعاب`

Use `/games` in `🤖・أوامر-الألعاب` to display the game panel. Everyone can
participate in an active game, but only members with the Game Master role can
start a new game from the panel. The available games are number guessing,
rock-paper-scissors, questions, dice, and an information quiz. Wins award 10
points and participation awards 2 points. Scores persist across restarts.

## Server verification

Run `/setup-verify` in the channel where you want the verification message.
The bot creates the `MEMBER` role if it does not already exist. Members who
click **✅ Verify** receive that role once; clicking again does not add it a
second time.

## Setup

1. Create a Discord application in the [Discord Developer Portal](https://discord.com/developers/applications).
2. Add a bot user and copy its token.
3. Store the token as the Replit secret `DISCORD_BOT_TOKEN`.
4. Invite the bot to a server using the `bot` and `applications.commands` scopes.
5. Enable the **Server Members Intent** for the bot in the Discord Developer
   Portal.
6. Grant the bot the `Manage Roles` permission and place its bot role above
   `MEMBER` in the server role list.
7. Grant the bot the `Manage Channels` and `Send Messages` permissions so it
   can create or use `WELCOME`.
8. Grant the bot `Read Message History`, `Embed Links`, and `Manage Messages`
   for ticket operation.
9. Do not grant the bot `Administrator`; the ticket system uses only the
   explicit permissions listed above.
10. Start the `911-bot` workflow.

The bot registers its slash commands globally after connecting. Discord may take
a short time to make newly registered global commands available.

This starter bot is not connected to emergency services and must not be used
for real emergency dispatch.