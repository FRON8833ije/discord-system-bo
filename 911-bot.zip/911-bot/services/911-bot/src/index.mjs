import {
  ActionRowBuilder,
  AttachmentBuilder,
  ButtonBuilder,
  ButtonStyle,
  ChannelType,
  Client,
  EmbedBuilder,
  Events,
  GatewayIntentBits,
  OverwriteType,
  PermissionsBitField,
  REST,
  Routes,
  SlashCommandBuilder,
  StringSelectMenuBuilder,
} from "discord.js";
import {
  existsSync,
  mkdirSync,
  readFileSync,
  writeFileSync,
} from "node:fs";
import { createServer } from "node:http";
import { dirname } from "node:path";
import { fileURLToPath } from "node:url";

const token = process.env.DISCORD_BOT_TOKEN;

if (!token) {
  throw new Error(
    "DISCORD_BOT_TOKEN is required. Add the Discord bot token to Replit Secrets before starting the bot.",
  );
}

const port = Number(process.env.PORT) || 3000;

const server = createServer((request, response) => {
  const isHealthRequest =
    request.url === "/health" || request.url === "/health/";
  const botIsReady = client.isReady();
  const botName = botIsReady ? client.user.tag : "جارٍ الاتصال...";

  response.writeHead(200, {
    "Content-Type": "text/html; charset=utf-8",
    "Cache-Control": "no-store",
  });
  response.end(`
    <!DOCTYPE html>
    <html lang="ar" dir="rtl">
      <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>911 Bot</title>
      </head>
      <body style="background:#111;color:white;text-align:center;font-family:Arial;padding:100px 20px">
        <h1>🤖 911 SYSTEM BOT</h1>
        <h2>${isHealthRequest ? "🩺 Health Check" : botIsReady ? "🟢 البوت يعمل" : "🟡 البوت يحاول الاتصال"}</h2>
        <p>${botIsReady ? `Discord Bot Online — ${botName}` : "Discord Bot Starting"}</p>
        <p>🏠 السيرفرات: ${client.guilds.cache.size}</p>
      </body>
    </html>
  `);
});

server.on("error", (error) => {
  console.error("❌ Web server error.", error);
});

server.listen(port, "0.0.0.0", () => {
  console.info(`🌐 Web server is listening on port ${port}.`);
});

const commands = [
  new SlashCommandBuilder()
    .setName("setup-ticket")
    .setDescription("Create the 911 support ticket panel."),
  new SlashCommandBuilder()
    .setName("setup-verify")
    .setDescription("Post the server rules and verification button."),
  new SlashCommandBuilder()
    .setName("ping")
    .setDescription("Check whether 911-bot is online."),
  new SlashCommandBuilder()
    .setName("help")
    .setDescription("Show the commands available in this server."),
  new SlashCommandBuilder()
    .setName("status")
    .setDescription("Show the bot's uptime and connection status."),
  new SlashCommandBuilder()
    .setName("games")
    .setDescription("Show the interactive 911 Discord games panel."),
  new SlashCommandBuilder()
    .setName("points")
    .setDescription("Show your game points or another player's points.")
    .addUserOption((option) =>
      option
        .setName("user")
        .setDescription("The player whose points you want to view.")
        .setRequired(false),
    ),
  new SlashCommandBuilder()
    .setName("leaderboard")
    .setDescription("Show the top 911 game players."),
  new SlashCommandBuilder()
    .setName("warn")
    .setDescription("Warn a server member.")
    .addUserOption((option) =>
      option
        .setName("member")
        .setDescription("The member to warn.")
        .setRequired(true),
    )
    .addStringOption((option) =>
      option
        .setName("reason")
        .setDescription("The reason for the warning.")
        .setMaxLength(500)
        .setRequired(true),
    ),
  new SlashCommandBuilder()
    .setName("warnings")
    .setDescription("View a member's warning history.")
    .addUserOption((option) =>
      option
        .setName("member")
        .setDescription("The member whose warnings you want to view.")
        .setRequired(true),
    ),
  new SlashCommandBuilder()
    .setName("clearwarn")
    .setDescription("Clear all warnings from a server member.")
    .addUserOption((option) =>
      option
        .setName("member")
        .setDescription("The member whose warnings you want to clear.")
        .setRequired(true),
    ),
].map((command) => command.toJSON());

const client = new Client({
  intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMembers],
});

const memberRoleName = "MEMBER";
const staffRoleName = "🛡️・𝑺𝑻𝑨𝑭𝑭";
const legacyStaffRoleName = "STAFF";
const departmentRoleDefinitions = [
  {
    key: "support",
    roleName: "🛠️ 𝑺𝒖𝒑𝒑𝒐𝒓𝒕 𝑻𝒆𝒂𝒎",
    label: "Support",
    description: "مساعدة عامة واستفسارات",
  },
  {
    key: "administration",
    roleName: "👮 𝑴𝒐𝒅𝒆𝒓𝒂𝒕𝒐𝒓",
    label: "Administration",
    description: "التواصل مع الإدارة",
  },
  {
    key: "senior-administration",
    roleName: "👑 𝑺𝒆𝒏𝒊𝒐𝒓 𝑴𝒐𝒅",
    label: "Senior Administration",
    description: "طلبات الإدارة العليا",
  },
  {
    key: "complaint",
    roleName: "🚨 𝑪𝒐𝒎𝒑𝒍𝒂𝒊𝒏𝒕 𝑻𝒆𝒂𝒎",
    label: "Complaint / Report",
    description: "الشكاوى والبلاغات",
  },
  {
    key: "suggestion",
    roleName: "💡 𝑺𝒖𝒈𝒈𝒆𝒔𝒕𝒊𝒐𝒏 𝑻𝒆𝒂𝒎",
    label: "Suggestion",
    description: "الاقتراحات والأفكار",
  },
  {
    key: "admin",
    roleName: "👑 𝑨𝒅𝒎𝒊𝒏",
    label: "Administrators",
    description: "صلاحية الإدارة العامة",
  },
];
const ticketPanelChannelName = "🎫・𝑻𝑰𝑪𝑲𝑬𝑻";
const ticketChannelPrefix = "🎫・ticket-";
const ticketTopicPrefix = "911 ticket owner:";
const ticketDepartmentPrefix = " department:";
const verifyButtonId = "911-bot:verify";
const openTicketButtonId = "911-bot:ticket-open";
const departmentSelectId = "911-bot:ticket-department";
const closeTicketButtonId = "911-bot:ticket-close";
const confirmCloseButtonId = "911-bot:ticket-close-confirm";
const cancelCloseButtonId = "911-bot:ticket-close-cancel";
const ticketOpenings = new Set();

const GAME_ROLE_NAME = "🎮 𝑮𝒂𝒎𝒆 𝑴𝒂𝒔𝒕𝒆𝒓";
const legacyGameRoleName = "🎮・𝑮𝒂𝒎𝒆 𝑴𝒂𝒔𝒕𝒆𝒓";
const gameCategoryName = "🎮・ألعاب-ديسكورد";
const gameChannelDefinitions = [
  {
    key: "chat",
    name: "💬・دردشة-الألعاب",
    topic: "دردشة مجتمع ألعاب Discord 911.",
  },
  {
    key: "play",
    name: "🎮・لعب-معنا",
    topic: "لعب جماعي وتكوين فرق.",
  },
  {
    key: "challenges",
    name: "🏆・تحديات-الألعاب",
    topic: "الألعاب والتحديات التفاعلية بين أعضاء السيرفر.",
  },
  {
    key: "results",
    name: "📊・نتائج-الألعاب",
    topic: "نتائج الألعاب والفائزون.",
  },
  {
    key: "commands",
    name: "🤖・أوامر-الألعاب",
    topic: "استخدم /games و /points و /leaderboard هنا.",
  },
];
const gameStartPrefix = "911-games:start:";
const gameGuessPrefix = "911-games:guess:";
const gameRpsPrefix = "911-games:rps:";
const gameAnswerPrefix = "911-games:answer:";
const gameDicePrefix = "911-games:dice:";
const gameScoresPath = fileURLToPath(
  new URL("../data/game-scores.json", import.meta.url),
);
const WARN_ROLE_NAME = "⚠️・𝑾𝑨𝑹𝑵";
const WARN_LOG_CHANNEL = "📋・𝑾𝒂𝒓𝒏-𝑳𝒐𝒈𝒔";
const warningsPath = fileURLToPath(
  new URL("../data/warnings.json", import.meta.url),
);
const gameScores = new Map();
const warnings = new Map();
const activeGames = new Map();
let nextGameId = 1;
const gameQuestionBank = [
  {
    prompt: "ما هو الكوكب المعروف باسم الكوكب الأحمر؟",
    options: ["الأرض", "المريخ", "المشتري", "الزهرة"],
    correctIndex: 1,
  },
  {
    prompt: "كم عدد أضلاع المثلث؟",
    options: ["2", "3", "4", "5"],
    correctIndex: 1,
  },
  {
    prompt: "ما هي عاصمة العراق؟",
    options: ["البصرة", "الموصل", "بغداد", "أربيل"],
    correctIndex: 2,
  },
  {
    prompt: "أي حيوان يُعرف بأنه أسرع حيوان بري؟",
    options: ["الأسد", "الفهد", "الحصان", "الذئب"],
    correctIndex: 1,
  },
  {
    prompt: "كم عدد أيام الأسبوع؟",
    options: ["5", "6", "7", "8"],
    correctIndex: 2,
  },
];

async function getOrCreateMemberRole(guild) {
  let memberRole = guild.roles.cache.find(
    (role) => role.name === memberRoleName,
  );

  if (!memberRole) {
    memberRole = await guild.roles.create({
      name: memberRoleName,
      reason: "Required by the 911-bot server verification system.",
    });
    console.info(`Created the ${memberRoleName} role in ${guild.name}.`);
  }

  return memberRole;
}

async function assertMemberRoleIsAssignable(guild, memberRole) {
  const botMember = guild.members.me ?? (await guild.members.fetchMe());

  if (!botMember.permissions.has(PermissionsBitField.Flags.ManageRoles)) {
    throw new Error(
      `The bot does not have Manage Roles permission in ${guild.name}.`,
    );
  }

  if (
    memberRole.managed ||
    botMember.roles.highest.comparePositionTo(memberRole) <= 0
  ) {
    throw new Error(
      `The bot role must be above ${memberRoleName} in ${guild.name}.`,
    );
  }
}

async function getOrCreateStaffRole(guild) {
  let staffRole = guild.roles.cache.find(
    (role) =>
      role.name === staffRoleName || role.name === legacyStaffRoleName,
  );

  if (!staffRole) {
    staffRole = await guild.roles.create({
      name: staffRoleName,
      reason: "Required by the 911-bot support ticket system.",
    });
    console.info(`Created the STAFF role in ${guild.name}.`);
  }

  return staffRole;
}

async function getOrCreateDepartmentRoles(guild) {
  const departmentRoles = {};

  for (const definition of departmentRoleDefinitions) {
    let role = guild.roles.cache.find(
      (candidate) => candidate.name === definition.roleName,
    );

    if (!role) {
      role = await guild.roles.create({
        name: definition.roleName,
        reason: `Required by the 911-bot ${definition.label} ticket routing.`,
      });
      console.info(`Created the ${definition.roleName} role in ${guild.name}.`);
    }

    departmentRoles[definition.key] = role;
  }

  return departmentRoles;
}

async function getOrCreateGameMasterRole(guild) {
  let gameMasterRole = guild.roles.cache.find(
    (role) =>
      role.name === GAME_ROLE_NAME || role.name === legacyGameRoleName,
  );

  if (!gameMasterRole) {
    gameMasterRole = await guild.roles.create({
      name: GAME_ROLE_NAME,
      permissions: [],
      reason: "Required by the 911-bot Discord games system.",
    });
    console.info(`Created the ${GAME_ROLE_NAME} role in ${guild.name}.`);
  }

  return gameMasterRole;
}

async function getOrCreateGameChannels(guild) {
  let category = guild.channels.cache.find(
    (channel) =>
      channel.name === gameCategoryName &&
      channel.type === ChannelType.GuildCategory,
  );

  if (!category) {
    category = await guild.channels.create({
      name: gameCategoryName,
      type: ChannelType.GuildCategory,
      reason: "Required by the 911-bot Discord games system.",
    });
    console.info(`Created the games category in ${guild.name}.`);
  }

  const channels = { category };

  for (const definition of gameChannelDefinitions) {
    let channel = guild.channels.cache.find(
      (candidate) =>
        candidate.name === definition.name &&
        candidate.type === ChannelType.GuildText,
    );

    if (!channel) {
      channel = await guild.channels.create({
        name: definition.name,
        type: ChannelType.GuildText,
        parent: category.id,
        topic: definition.topic,
        reason: "Required by the 911-bot Discord games system.",
      });
      console.info(`Created ${definition.name} in ${guild.name}.`);
    } else if (channel.parentId !== category.id) {
      await channel.setParent(category.id, {
        lockPermissions: false,
        reason: "Organize the 911-bot Discord games channels.",
      });
    }

    channels[definition.key] = channel;
  }

  return channels;
}

function loadGameScores() {
  if (!existsSync(gameScoresPath)) {
    return;
  }

  try {
    const savedScores = JSON.parse(readFileSync(gameScoresPath, "utf8"));

    for (const [key, score] of Object.entries(savedScores)) {
      if (
        score &&
        Number.isFinite(score.points) &&
        Number.isFinite(score.wins) &&
        Number.isFinite(score.participations)
      ) {
        gameScores.set(key, {
          points: score.points,
          wins: score.wins,
          participations: score.participations,
          displayName: score.displayName ?? "Player",
        });
      }
    }
  } catch (error) {
    console.error("Game scores could not be loaded.", error);
  }
}

function saveGameScores() {
  try {
    mkdirSync(dirname(gameScoresPath), { recursive: true });
    writeFileSync(
      gameScoresPath,
      JSON.stringify(Object.fromEntries(gameScores), null, 2),
    );
  } catch (error) {
    console.error("Game scores could not be saved.", error);
  }
}

function getGameScore(guildId, userId) {
  const key = `${guildId}:${userId}`;
  const score = gameScores.get(key);

  if (score) {
    return score;
  }

  const newScore = {
    points: 0,
    wins: 0,
    participations: 0,
    displayName: "Player",
  };
  gameScores.set(key, newScore);
  return newScore;
}

function recordGameParticipation(guildId, user) {
  const score = getGameScore(guildId, user.id);
  score.points += 2;
  score.participations += 1;
  score.displayName = user.globalName ?? user.username;
  saveGameScores();
}

function recordGameWin(guildId, user) {
  const score = getGameScore(guildId, user.id);
  score.points += 10;
  score.wins += 1;
  score.displayName = user.globalName ?? user.username;
  saveGameScores();
}

function warningKey(guildId, memberId) {
  return `${guildId}:${memberId}`;
}

function loadWarnings() {
  if (!existsSync(warningsPath)) {
    return;
  }

  try {
    const savedWarnings = JSON.parse(readFileSync(warningsPath, "utf8"));

    for (const [key, memberWarnings] of Object.entries(savedWarnings)) {
      if (!Array.isArray(memberWarnings)) {
        continue;
      }

      warnings.set(
        key,
        memberWarnings.map((warning) => ({
          moderator: warning.moderator ?? "unknown",
          reason: warning.reason ?? "No reason provided",
          date: warning.date ?? new Date(0).toISOString(),
        })),
      );
    }
  } catch (error) {
    console.error("Warnings could not be loaded.", error);
  }
}

function saveWarnings() {
  try {
    mkdirSync(dirname(warningsPath), { recursive: true });
    writeFileSync(
      warningsPath,
      JSON.stringify(Object.fromEntries(warnings), null, 2),
    );
  } catch (error) {
    console.error("Warnings could not be saved.", error);
  }
}

async function setupWarnSystem(guild) {
  let warnRole = guild.roles.cache.find(
    (role) => role.name === WARN_ROLE_NAME,
  );

  if (!warnRole) {
    warnRole = await guild.roles.create({
      name: WARN_ROLE_NAME,
      colors: { primary: 0xff0000 },
      permissions: [],
      reason: "911 Warn System",
    });
    console.info(`Created the ${WARN_ROLE_NAME} role in ${guild.name}.`);
  }

  let logChannel = guild.channels.cache.find(
    (channel) => channel.name === WARN_LOG_CHANNEL,
  );

  if (logChannel && logChannel.type !== ChannelType.GuildText) {
    throw new Error(
      `The existing ${WARN_LOG_CHANNEL} channel in ${guild.name} is not a text channel.`,
    );
  }

  if (!logChannel) {
    logChannel = await guild.channels.create({
      name: WARN_LOG_CHANNEL,
      type: ChannelType.GuildText,
      reason: "911 Warn Logs",
    });
    console.info(`Created the ${WARN_LOG_CHANNEL} channel in ${guild.name}.`);
  }

  return { warnRole, logChannel };
}

function gameSessionKey(guildId, type) {
  return `${guildId}:${type}`;
}

function findActiveGame(guildId, sessionId) {
  return Array.from(activeGames.values()).find(
    (session) =>
      session.guildId === guildId && session.id === sessionId && !session.finished,
  );
}

function createGamesPanelMessage() {
  const panelEmbed = new EmbedBuilder()
    .setColor(0x00ff66)
    .setTitle("🎮 ألعاب Discord في 911")
    .setDescription(
      "اختر لعبة للمشاركة.\n\n" +
        "يستطيع الجميع المشاركة في الألعاب، بينما يحتاج تشغيل لعبة جديدة إلى رتبة 🎮 Game Master.\n" +
        "الفوز = **10 نقاط**، والمشاركة = **نقطتان**.",
    )
    .setFooter({ text: "استخدم لوحة الألعاب داخل قسم ألعاب ديسكورد" });

  const buttons = [
    new ButtonBuilder()
      .setCustomId(`${gameStartPrefix}guess`)
      .setLabel("🎯 تخمين الرقم")
      .setStyle(ButtonStyle.Primary),
    new ButtonBuilder()
      .setCustomId(`${gameStartPrefix}rps`)
      .setLabel("✂️ حجر ورقة مقص")
      .setStyle(ButtonStyle.Success),
    new ButtonBuilder()
      .setCustomId(`${gameStartPrefix}questions`)
      .setLabel("❓ أسئلة")
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId(`${gameStartPrefix}dice`)
      .setLabel("🎲 نرد")
      .setStyle(ButtonStyle.Primary),
    new ButtonBuilder()
      .setCustomId(`${gameStartPrefix}quiz`)
      .setLabel("🧠 مسابقة")
      .setStyle(ButtonStyle.Danger),
  ];

  return {
    embeds: [panelEmbed],
    components: [new ActionRowBuilder().addComponents(buttons)],
  };
}

function createGameSession(guildId, type, challengeChannelId) {
  const session = {
    id: String(nextGameId++),
    guildId,
    type,
    channelId: challengeChannelId,
    messageId: null,
    participants: new Map(),
    finished: false,
    timeout: null,
  };

  if (type === "guess") {
    session.secretNumber = Math.floor(Math.random() * 5) + 1;
  }

  if (type === "questions" || type === "quiz") {
    session.question =
      gameQuestionBank[Math.floor(Math.random() * gameQuestionBank.length)];
  }

  return session;
}

function getGameTypeTitle(type) {
  return {
    guess: "🎯 تخمين الرقم",
    rps: "✂️ حجر ورقة مقص",
    questions: "❓ أسئلة عامة",
    dice: "🎲 رمي النرد",
    quiz: "🧠 مسابقة معلومات",
  }[type] ?? "🎮 لعبة";
}

function createGameSessionMessage(session) {
  const title = getGameTypeTitle(session.type);
  const embed = new EmbedBuilder()
    .setColor(0x00ff66)
    .setTitle(title)
    .setFooter({ text: "المشاركة +2 نقاط • الفوز +10 نقاط" });

  if (session.type === "guess") {
    embed.setDescription(
      "خمن الرقم الصحيح من 1 إلى 5.\nلكل لاعب محاولة واحدة فقط.",
    );

    return {
      embeds: [embed],
      components: [
        new ActionRowBuilder().addComponents(
          [1, 2, 3, 4, 5].map((number) =>
            new ButtonBuilder()
              .setCustomId(`${gameGuessPrefix}${session.id}:${number}`)
              .setLabel(String(number))
              .setStyle(ButtonStyle.Primary),
          ),
        ),
      ],
    };
  }

  if (session.type === "rps") {
    embed.setDescription(
      "أول لاعبين يختاران يدخلان الجولة.\nاختر حركتك مرة واحدة.",
    );

    return {
      embeds: [embed],
      components: [
        new ActionRowBuilder().addComponents(
          new ButtonBuilder()
            .setCustomId(`${gameRpsPrefix}${session.id}:rock`)
            .setLabel("🪨 حجر")
            .setStyle(ButtonStyle.Primary),
          new ButtonBuilder()
            .setCustomId(`${gameRpsPrefix}${session.id}:paper`)
            .setLabel("📄 ورقة")
            .setStyle(ButtonStyle.Success),
          new ButtonBuilder()
            .setCustomId(`${gameRpsPrefix}${session.id}:scissors`)
            .setLabel("✂️ مقص")
            .setStyle(ButtonStyle.Danger),
        ),
      ],
    };
  }

  if (session.type === "questions" || session.type === "quiz") {
    embed.setDescription(session.question.prompt);

    return {
      embeds: [embed],
      components: [
        new ActionRowBuilder().addComponents(
          session.question.options.map((option, index) =>
            new ButtonBuilder()
              .setCustomId(`${gameAnswerPrefix}${session.id}:${index}`)
              .setLabel(`${index + 1}. ${option}`)
              .setStyle(ButtonStyle.Primary),
          ),
        ),
      ],
    };
  }

  embed.setDescription(
    "اضغط على الزر وارمِ النرد مرة واحدة.\nستنتهي الجولة بعد 30 ثانية، وصاحب أعلى نتيجة يفوز.",
  );

  return {
    embeds: [embed],
    components: [
      new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId(`${gameDicePrefix}${session.id}:roll`)
          .setLabel("🎲 ارْمِ النرد")
          .setStyle(ButtonStyle.Primary),
      ),
    ],
  };
}

function createFinishedGameMessage(session, description) {
  const embed = new EmbedBuilder()
    .setColor(0x5865f2)
    .setTitle(`${getGameTypeTitle(session.type)} — انتهت`)
    .setDescription(description)
    .setFooter({ text: "تحقق من 📊・نتائج-الألعاب لرؤية النتائج" });

  return { embeds: [embed], components: [] };
}

function closeGameSession(session) {
  session.finished = true;
  activeGames.delete(gameSessionKey(session.guildId, session.type));

  if (session.timeout) {
    clearTimeout(session.timeout);
    session.timeout = null;
  }
}

async function updateGameMessage(session, payload) {
  const channel = await client.channels.fetch(session.channelId);

  if (!channel?.isTextBased()) {
    return;
  }

  const message = await channel.messages.fetch(session.messageId);
  await message.edit(payload);
}

async function postGameResult(guild, session, description) {
  try {
    const channels = await getOrCreateGameChannels(guild);
    await channels.results.send({
      embeds: [
        new EmbedBuilder()
          .setColor(0x00ff66)
          .setTitle(`📊 نتيجة ${getGameTypeTitle(session.type)}`)
          .setDescription(description)
          .setFooter({ text: "911 Games" }),
      ],
    });
  } catch (error) {
    console.error("Game result could not be posted.", error);
  }
}

async function expireGameSession(session) {
  if (session.finished) {
    return;
  }

  const guild = client.guilds.cache.get(session.guildId);
  const players = Array.from(session.participants.values());
  let description = "انتهت الجولة دون فائز.";

  if (session.type === "dice" && players.length > 0) {
    const highestRoll = Math.max(...players.map((player) => player.roll));
    const winners = players.filter((player) => player.roll === highestRoll);

    for (const winner of winners) {
      recordGameWin(session.guildId, winner.user);
    }

    description =
      winners.length === 1
        ? `الفائز: ${winners[0].user.username} برمية **${highestRoll}** 🎉`
        : `تعادل ${winners.map((winner) => winner.user.username).join(" و ")} برمية **${highestRoll}** 🎉`;
  }

  if (session.type === "guess") {
    description = `انتهت الجولة. الرقم الصحيح كان **${session.secretNumber}**.`;
  }

  if (session.type === "rps") {
    description = "انتهت الجولة قبل اكتمال اختيار لاعبين.";
  }

  if (session.type === "questions" || session.type === "quiz") {
    description = `انتهى الوقت. الإجابة الصحيحة كانت **${session.question.options[session.question.correctIndex]}**.`;
  }

  closeGameSession(session);

  try {
    await updateGameMessage(
      session,
      createFinishedGameMessage(session, description),
    );
  } catch (error) {
    console.error("Game message could not be finalized.", error);
  }

  if (guild) {
    await postGameResult(guild, session, description);
  }
}

async function requireGamesCommandChannel(interaction) {
  const channels = await getOrCreateGameChannels(interaction.guild);

  if (interaction.channelId !== channels.commands.id) {
    await interaction.reply({
      content: `استخدم أوامر الألعاب داخل <#${channels.commands.id}> فقط.`,
      ephemeral: true,
    });
    return null;
  }

  return channels;
}

async function startGameFromButton(interaction, type) {
  if (!interaction.inGuild()) {
    await interaction.reply({
      content: "الألعاب متاحة داخل السيرفر فقط.",
      ephemeral: true,
    });
    return;
  }

  try {
    const gameMasterRole = await getOrCreateGameMasterRole(interaction.guild);

    if (!isGameMaster(interaction, gameMasterRole)) {
      await interaction.reply({
        content:
          "❌ ما عندك صلاحية تشغيل الألعاب. تحتاج رتبة 🎮 Game Master.",
        ephemeral: true,
      });
      return;
    }

    await interaction.deferReply({ ephemeral: true });
    const channels = await getOrCreateGameChannels(interaction.guild);
    const key = gameSessionKey(interaction.guild.id, type);

    if (activeGames.has(key)) {
      await interaction.editReply(
        `هناك لعبة ${getGameTypeTitle(type)} نشطة حالياً في <#${channels.challenges.id}>.`,
      );
      return;
    }

    const session = createGameSession(
      interaction.guild.id,
      type,
      channels.challenges.id,
    );
    activeGames.set(key, session);

    try {
      const gameMessage = await channels.challenges.send(
        createGameSessionMessage(session),
      );
      session.messageId = gameMessage.id;
      session.timeout = setTimeout(
        () => expireGameSession(session),
        type === "dice" ? 30_000 : 45_000,
      );
    } catch (error) {
      activeGames.delete(key);
      throw error;
    }

    await interaction.editReply(
      `تم تشغيل ${getGameTypeTitle(type)} في <#${channels.challenges.id}>.`,
    );
  } catch (error) {
    console.error("Game could not be started.", error);
    await interaction.editReply(
      "تعذر تشغيل اللعبة. تأكد من صلاحيات البوت في قسم ألعاب ديسكورد.",
    );
  }
}

function getRpsWinner(first, second) {
  if (first.choice === second.choice) {
    return null;
  }

  const winningChoices = {
    rock: "scissors",
    paper: "rock",
    scissors: "paper",
  };

  return winningChoices[first.choice] === second.choice ? first : second;
}

async function handleGameButton(interaction) {
  if (!interaction.inGuild()) {
    await interaction.reply({
      content: "الألعاب متاحة داخل السيرفر فقط.",
      ephemeral: true,
    });
    return;
  }

  if (interaction.customId.startsWith(gameGuessPrefix)) {
    const [sessionId, numberText] = interaction.customId
      .slice(gameGuessPrefix.length)
      .split(":");
    const session = findActiveGame(interaction.guild.id, sessionId);
    const number = Number(numberText);

    if (!session) {
      await interaction.reply({
        content: "انتهت هذه الجولة أو لم تعد متاحة.",
        ephemeral: true,
      });
      return;
    }

    if (session.participants.has(interaction.user.id)) {
      await interaction.reply({
        content: "استخدمت محاولتك في هذه الجولة بالفعل.",
        ephemeral: true,
      });
      return;
    }

    session.participants.set(interaction.user.id, { user: interaction.user });
    recordGameParticipation(interaction.guild.id, interaction.user);

    if (number !== session.secretNumber) {
      await interaction.reply({
        content: "❌ تخمين غير صحيح. حظاً أوفر في الجولة القادمة!",
        ephemeral: true,
      });
      return;
    }

    recordGameWin(interaction.guild.id, interaction.user);
    closeGameSession(session);
    const description = `🎉 الفائز هو ${interaction.user.username}!\nالرقم الصحيح كان **${session.secretNumber}**.\nحصل الفائز على **10 نقاط** بالإضافة إلى نقاط المشاركة.`;
    await interaction.update(
      createFinishedGameMessage(session, description),
    );
    await postGameResult(interaction.guild, session, description);
    return;
  }

  if (interaction.customId.startsWith(gameRpsPrefix)) {
    const [sessionId, choice] = interaction.customId
      .slice(gameRpsPrefix.length)
      .split(":");
    const session = findActiveGame(interaction.guild.id, sessionId);

    if (!session) {
      await interaction.reply({
        content: "انتهت هذه الجولة أو لم تعد متاحة.",
        ephemeral: true,
      });
      return;
    }

    if (session.participants.has(interaction.user.id)) {
      await interaction.reply({
        content: "اخترت حركة في هذه الجولة بالفعل.",
        ephemeral: true,
      });
      return;
    }

    session.participants.set(interaction.user.id, {
      user: interaction.user,
      choice,
    });
    recordGameParticipation(interaction.guild.id, interaction.user);

    if (session.participants.size < 2) {
      await interaction.reply({
        content: "تم تسجيل اختيارك. بانتظار لاعب آخر...",
        ephemeral: true,
      });
      return;
    }

    const players = Array.from(session.participants.values()).slice(0, 2);
    const winner = getRpsWinner(players[0], players[1]);
    let description;

    if (!winner) {
      description = `تعادل ${players[0].user.username} و ${players[1].user.username} 🤝`;
    } else {
      recordGameWin(interaction.guild.id, winner.user);
      description = `🎉 الفائز هو ${winner.user.username}!\nحصل الفائز على **10 نقاط** بالإضافة إلى نقاط المشاركة.`;
    }

    closeGameSession(session);
    await interaction.update(
      createFinishedGameMessage(session, description),
    );
    await postGameResult(interaction.guild, session, description);
    return;
  }

  if (interaction.customId.startsWith(gameAnswerPrefix)) {
    const [sessionId, answerText] = interaction.customId
      .slice(gameAnswerPrefix.length)
      .split(":");
    const session = findActiveGame(interaction.guild.id, sessionId);
    const answerIndex = Number(answerText);

    if (!session) {
      await interaction.reply({
        content: "انتهت هذه الجولة أو لم تعد متاحة.",
        ephemeral: true,
      });
      return;
    }

    if (session.participants.has(interaction.user.id)) {
      await interaction.reply({
        content: "أجبت عن هذا السؤال بالفعل.",
        ephemeral: true,
      });
      return;
    }

    session.participants.set(interaction.user.id, { user: interaction.user });
    recordGameParticipation(interaction.guild.id, interaction.user);

    if (answerIndex !== session.question.correctIndex) {
      await interaction.reply({
        content: "❌ إجابة غير صحيحة. تم احتساب نقطتي المشاركة.",
        ephemeral: true,
      });
      return;
    }

    recordGameWin(interaction.guild.id, interaction.user);
    closeGameSession(session);
    const description = `🎉 إجابة صحيحة! الفائز هو ${interaction.user.username}.\nحصل الفائز على **10 نقاط** بالإضافة إلى نقاط المشاركة.`;
    await interaction.update(
      createFinishedGameMessage(session, description),
    );
    await postGameResult(interaction.guild, session, description);
    return;
  }

  if (interaction.customId.startsWith(gameDicePrefix)) {
    const [sessionId] = interaction.customId
      .slice(gameDicePrefix.length)
      .split(":");
    const session = findActiveGame(interaction.guild.id, sessionId);

    if (!session) {
      await interaction.reply({
        content: "انتهت هذه الجولة أو لم تعد متاحة.",
        ephemeral: true,
      });
      return;
    }

    if (session.participants.has(interaction.user.id)) {
      await interaction.reply({
        content: "رميت النرد في هذه الجولة بالفعل.",
        ephemeral: true,
      });
      return;
    }

    const roll = Math.floor(Math.random() * 6) + 1;
    session.participants.set(interaction.user.id, {
      user: interaction.user,
      roll,
    });
    recordGameParticipation(interaction.guild.id, interaction.user);

    await interaction.reply({
      content: `🎲 نتيجتك هي **${roll}**. انتظر انتهاء الجولة لمعرفة الفائز.`,
      ephemeral: true,
    });
  }
}

function isGameMaster(interaction, gameMasterRole) {
  return Boolean(interaction.member?.roles?.cache?.has(gameMasterRole.id));
}

function getDepartmentDefinition(departmentKey) {
  return (
    departmentRoleDefinitions.find(
      (definition) => definition.key === departmentKey,
    ) ?? departmentRoleDefinitions[0]
  );
}

async function assertBotHasTicketPermissions(guild) {
  const botMember = guild.members.me ?? (await guild.members.fetchMe());
  const requiredPermissions = [
    PermissionsBitField.Flags.ManageChannels,
    PermissionsBitField.Flags.ManageRoles,
    PermissionsBitField.Flags.ViewChannel,
    PermissionsBitField.Flags.SendMessages,
    PermissionsBitField.Flags.ReadMessageHistory,
    PermissionsBitField.Flags.EmbedLinks,
    PermissionsBitField.Flags.ManageMessages,
  ];

  const missingPermissions = requiredPermissions.filter(
    (permission) => !botMember.permissions.has(permission),
  );

  if (missingPermissions.length > 0) {
    throw new Error(
      `The bot is missing required ticket permissions in ${guild.name}.`,
    );
  }
}

async function assertRoleIsBelowBot(guild, role, roleLabel) {
  const botMember = guild.members.me ?? (await guild.members.fetchMe());

  if (
    role.managed ||
    botMember.roles.highest.comparePositionTo(role) <= 0
  ) {
    throw new Error(
      `The bot role must be above ${roleLabel} in ${guild.name}.`,
    );
  }
}

const WELCOME_CHANNEL_NAME = "👋-𝐖𝐄𝐋𝐂𝐎𝐌𝐄";

function getWelcomeChannel(guild) {
  return guild.channels.cache.find(
    (channel) =>
      channel.name === WELCOME_CHANNEL_NAME && channel.isTextBased(),
  );
}

async function getOrCreateTicketPanelChannel(guild) {
  let ticketPanelChannel = guild.channels.cache.find(
    (channel) =>
      channel.name === ticketPanelChannelName &&
      channel.type === ChannelType.GuildText,
  );

  if (!ticketPanelChannel) {
    ticketPanelChannel = await guild.channels.create({
      name: ticketPanelChannelName,
      type: ChannelType.GuildText,
      reason: "Required by the 911-bot support ticket system.",
    });
    console.info(`Created the ticket panel channel in ${guild.name}.`);
  }

  return ticketPanelChannel;
}

function createTicketPanelMessage() {
  const panelEmbed = new EmbedBuilder()
    .setColor(0x5865f2)
    .setTitle("🎫 911 SUPPORT")
    .setDescription(
      "إذا تحتاج مساعدة أو تريد التواصل مع الإدارة،\nاضغط على الزر أدناه لفتح تذكرة.",
    )
    .setFooter({ text: "911 Support • فريق الإدارة جاهز لمساعدتك" });

  const openButton = new ButtonBuilder()
    .setCustomId(openTicketButtonId)
    .setLabel("🎫 Open Ticket")
    .setStyle(ButtonStyle.Primary);

  const departmentSelect = new StringSelectMenuBuilder()
    .setCustomId(departmentSelectId)
    .setPlaceholder("اختر القسم قبل فتح التذكرة")
    .addOptions(
      departmentRoleDefinitions
        .filter((definition) => definition.key !== "admin")
        .map((definition) => ({
          label: definition.label,
          value: definition.key,
          description: definition.description,
        })),
    );

  return {
    embeds: [panelEmbed],
    components: [
      new ActionRowBuilder().addComponents(departmentSelect),
      new ActionRowBuilder().addComponents(openButton),
    ],
  };
}

function createTicketMessage(departmentDefinition, departmentRole) {
  const ticketImage = new AttachmentBuilder("./ticket.png", {
    name: "ticket.png",
  });

  const ticketEmbed = new EmbedBuilder()
    .setColor(0x00ff66)
    .setTitle("🎫 نظام التذاكر")
    .setDescription(
      "مرحباً بك في تذكرتك!\n\n" +
        "يرجى توضيح مشكلتك وانتظار أحد أعضاء الفريق.\n\n" +
        "Please be patient and do not spam the ticket.",
    )
    .setImage("attachment://ticket.png")
    .addFields({
      name: "القسم المسؤول",
      value: `${departmentDefinition.label} • <@&${departmentRole.id}>`,
    })
    .setFooter({ text: "911 Support • سيتم التعامل مع طلبك بسرية" });

  const closeButton = new ButtonBuilder()
    .setCustomId(closeTicketButtonId)
    .setLabel("🔒 Close Ticket")
    .setStyle(ButtonStyle.Danger);

  return {
    content: `👥 <@&${departmentRole.id}>`,
    embeds: [ticketEmbed],
    files: [ticketImage],
    components: [new ActionRowBuilder().addComponents(closeButton)],
    allowedMentions: { roles: [departmentRole.id] },
  };
}

function createCloseConfirmationMessage() {
  const confirmButton = new ButtonBuilder()
    .setCustomId(confirmCloseButtonId)
    .setLabel("✅ Confirm Close")
    .setStyle(ButtonStyle.Danger);
  const cancelButton = new ButtonBuilder()
    .setCustomId(cancelCloseButtonId)
    .setLabel("❌ Cancel")
    .setStyle(ButtonStyle.Secondary);

  return {
    content: "هل أنت متأكد من إغلاق التذكرة؟",
    components: [
      new ActionRowBuilder().addComponents(confirmButton, cancelButton),
    ],
    ephemeral: true,
  };
}

function getTicketOwnerId(channel) {
  if (!channel.topic?.startsWith(ticketTopicPrefix)) {
    return null;
  }

  return channel.topic
    .slice(ticketTopicPrefix.length)
    .split(ticketDepartmentPrefix)[0];
}

function getTicketDepartmentKey(channel) {
  const departmentMarker = channel.topic?.indexOf(ticketDepartmentPrefix);

  if (departmentMarker === undefined || departmentMarker < 0) {
    return "support";
  }

  const departmentKey = channel.topic
    .slice(departmentMarker + ticketDepartmentPrefix.length)
    .trim();

  return getDepartmentDefinition(departmentKey).key;
}

function findOpenTicket(guild, memberId) {
  return guild.channels.cache.find(
    (channel) =>
      channel.type === ChannelType.GuildText &&
      (channel.topic === `${ticketTopicPrefix}${memberId}` ||
        channel.topic?.startsWith(
          `${ticketTopicPrefix}${memberId}${ticketDepartmentPrefix}`,
        )),
  );
}

function getTicketChannelName(member) {
  const safeUsername =
    member.user.username
      .toLowerCase()
      .replace(/[^a-z0-9-]/g, "-")
      .replace(/-+/g, "-")
      .replace(/^-|-$/g, "")
      .slice(0, 80) || member.id;

  return `${ticketChannelPrefix}${safeUsername}`.slice(0, 100);
}

async function createMemberTicket(
  guild,
  member,
  staffRole,
  departmentRole,
  adminRole,
  departmentKey,
) {
  const roleOverwrites = new Map([
    [staffRole.id, staffRole],
    [departmentRole.id, departmentRole],
    [adminRole.id, adminRole],
  ]);

  const ticketChannel = await guild.channels.create({
    name: getTicketChannelName(member),
    type: ChannelType.GuildText,
    topic: `${ticketTopicPrefix}${member.id}${ticketDepartmentPrefix}${departmentKey}`,
    reason: `Support ticket opened by ${member.user.tag}.`,
    permissionOverwrites: [
      {
        id: guild.roles.everyone.id,
        type: OverwriteType.Role,
        deny: [PermissionsBitField.Flags.ViewChannel],
      },
      {
        id: member.id,
        type: OverwriteType.Member,
        allow: [
          PermissionsBitField.Flags.ViewChannel,
          PermissionsBitField.Flags.SendMessages,
          PermissionsBitField.Flags.ReadMessageHistory,
        ],
      },
      ...Array.from(roleOverwrites.keys()).map((roleId) => ({
        id: roleId,
        type: OverwriteType.Role,
        allow: [
          PermissionsBitField.Flags.ViewChannel,
          PermissionsBitField.Flags.SendMessages,
          PermissionsBitField.Flags.ReadMessageHistory,
        ],
      })),
      {
        id: client.user.id,
        type: OverwriteType.Member,
        allow: [
          PermissionsBitField.Flags.ViewChannel,
          PermissionsBitField.Flags.SendMessages,
          PermissionsBitField.Flags.ReadMessageHistory,
          PermissionsBitField.Flags.ManageChannels,
          PermissionsBitField.Flags.ManageMessages,
          PermissionsBitField.Flags.EmbedLinks,
        ],
      },
    ],
  });

  await ticketChannel.send(createTicketMessage(
    getDepartmentDefinition(departmentKey),
    departmentRole,
  ));
  return ticketChannel;
}

async function isTicketParticipant(interaction, ticketChannel) {
  const ownerId = getTicketOwnerId(ticketChannel);

  if (!ownerId) {
    return false;
  }

  if (interaction.user.id === ownerId) {
    return true;
  }

  const member = await interaction.guild.members.fetch(interaction.user.id);
  if (member.permissions.has(PermissionsBitField.Flags.Administrator)) {
    return true;
  }

  const staffRole = await getOrCreateStaffRole(interaction.guild);
  const departmentRoles = await getOrCreateDepartmentRoles(interaction.guild);
  const departmentRole = departmentRoles[getTicketDepartmentKey(ticketChannel)];
  const adminRole = departmentRoles.admin;

  return [staffRole.id, departmentRole.id, adminRole.id].some((roleId) =>
    member.roles.cache.has(roleId),
  );
}

function createWelcomeEmbed(member) {
  return new EmbedBuilder()
    .setColor(0x2b2d31)
    .setTitle("👋・أهلاً وسهلاً بك")
    .setDescription(
      `نورت السيرفر يا ${member} ❤️\n` +
        "نتمنى لك وقت ممتع معنا!",
    )
    .setThumbnail(member.user.displayAvatarURL({ dynamic: true }))
    .setFooter({ text: "911 Community" })
    .setTimestamp();
}

async function sendWelcomeMessage(member) {
  const welcomeChannel = getWelcomeChannel(member.guild);

  if (!welcomeChannel) {
    console.info(
      `Welcome channel ${WELCOME_CHANNEL_NAME} was not found in ${member.guild.name}.`,
    );
    return false;
  }

  await welcomeChannel.send({
    embeds: [createWelcomeEmbed(member)],
    allowedMentions: { users: [member.id] },
  });
  return true;
}

function createVerificationMessage() {
  const rulesEmbed = new EmbedBuilder()
    .setColor(0x2ecc71)
    .setTitle("Server Verification")
    .setDescription(
      "Please read the server rules below, then click **✅ Verify** to access the member area.",
    )
    .addFields(
      {
        name: "1. Be respectful",
        value: "Treat other members and staff with respect.",
      },
      {
        name: "2. Keep conversations appropriate",
        value: "Do not post spam, harassment, or unsafe content.",
      },
      {
        name: "3. Follow Discord's rules",
        value: "Use the server responsibly and follow Discord's Terms and Community Guidelines.",
      },
    )
    .setFooter({ text: "Verification is required only once." });

  const verifyButton = new ButtonBuilder()
    .setCustomId(verifyButtonId)
    .setLabel("✅ Verify")
    .setStyle(ButtonStyle.Success);

  return {
    embeds: [rulesEmbed],
    components: [new ActionRowBuilder().addComponents(verifyButton)],
  };
}

async function registerCommands(userId) {
  const rest = new REST({ version: "10" }).setToken(token);
  await rest.put(Routes.applicationCommands(userId), { body: commands });
  console.info(`Registered ${commands.length} global slash commands.`);
}

client.once(Events.ClientReady, async (readyClient) => {
  try {
    loadGameScores();
    loadWarnings();
    await registerCommands(readyClient.user.id);
    readyClient.user.setPresence({
      activities: [{ name: "/help for commands" }],
      status: "online",
    });

    for (const guild of readyClient.guilds.cache.values()) {
      try {
        await getOrCreateDepartmentRoles(guild);
      } catch (error) {
        console.error(
          `Department role initialization failed in ${guild.name}.`,
          error,
        );
      }

      try {
        await getOrCreateGameMasterRole(guild);
        await getOrCreateGameChannels(guild);
      } catch (error) {
        console.error(
          `Games system initialization failed in ${guild.name}.`,
          error,
        );
      }

      try {
        await setupWarnSystem(guild);
      } catch (error) {
        console.error(
          `Warn system initialization failed in ${guild.name}.`,
          error,
        );
      }
    }

    console.info(`Logged in as ${readyClient.user.tag}.`);
  } catch (error) {
    console.error("Discord command registration failed.", error);
    process.exitCode = 1;
  }
});

client.on(Events.InteractionCreate, async (interaction) => {
  if (
    interaction.isButton() &&
    interaction.customId.startsWith(gameStartPrefix)
  ) {
    await startGameFromButton(
      interaction,
      interaction.customId.slice(gameStartPrefix.length),
    );
    return;
  }

  if (
    interaction.isButton() &&
    (interaction.customId.startsWith(gameGuessPrefix) ||
      interaction.customId.startsWith(gameRpsPrefix) ||
      interaction.customId.startsWith(gameAnswerPrefix) ||
      interaction.customId.startsWith(gameDicePrefix))
  ) {
    try {
      await handleGameButton(interaction);
    } catch (error) {
      console.error("Game interaction failed.", error);

      if (!interaction.replied && !interaction.deferred) {
        await interaction.reply({
          content: "تعذر تنفيذ حركة اللعبة. حاول مرة أخرى.",
          ephemeral: true,
        });
      }
    }
    return;
  }

  if (
    (interaction.isButton() && interaction.customId === openTicketButtonId) ||
    (interaction.isStringSelectMenu() &&
      interaction.customId === departmentSelectId)
  ) {
    if (!interaction.inGuild()) {
      await interaction.reply({
        content: "فتح التذاكر متاح فقط داخل السيرفر.",
        ephemeral: true,
      });
      return;
    }

    await interaction.deferReply({ ephemeral: true });
    const openingKey = `${interaction.guild.id}:${interaction.user.id}`;
    const departmentKey = getDepartmentDefinition(
      interaction.isStringSelectMenu() ? interaction.values[0] : "support",
    ).key;

    if (ticketOpenings.has(openingKey)) {
      await interaction.editReply("جاري فتح تذكرتك، انتظر لحظات من فضلك.");
      return;
    }

    ticketOpenings.add(openingKey);

    try {
      await assertBotHasTicketPermissions(interaction.guild);
      const staffRole = await getOrCreateStaffRole(interaction.guild);
      const departmentRoles = await getOrCreateDepartmentRoles(
        interaction.guild,
      );
      const departmentRole = departmentRoles[departmentKey];
      const adminRole = departmentRoles.admin;
      await assertRoleIsBelowBot(
        interaction.guild,
        staffRole,
        "the STAFF role",
      );
      await assertRoleIsBelowBot(
        interaction.guild,
        departmentRole,
        "the assigned department role",
      );
      await assertRoleIsBelowBot(
        interaction.guild,
        adminRole,
        "the Admin role",
      );

      const existingTicket = findOpenTicket(
        interaction.guild,
        interaction.user.id,
      );

      if (existingTicket) {
        await interaction.editReply("عندك تذكرة مفتوحة بالفعل 🎫");
        return;
      }

      const member = await interaction.guild.members.fetch(interaction.user.id);
      const ticketChannel = await createMemberTicket(
        interaction.guild,
        member,
        staffRole,
        departmentRole,
        adminRole,
        departmentKey,
      );

      await interaction.editReply(
        `تم فتح تذكرتك بنجاح 🎫 <#${ticketChannel.id}>`,
      );
    } catch (error) {
      console.error("Ticket creation failed.", error);
      await interaction.editReply(
        "تعذر فتح التذكرة. تأكد من صلاحيات البوت وأن رتب STAFF والأقسام تحت رتبة البوت.",
      );
    } finally {
      ticketOpenings.delete(openingKey);
    }
    return;
  }

  if (interaction.isButton() && interaction.customId === closeTicketButtonId) {
    if (
      !interaction.inGuild() ||
      !interaction.channel ||
      interaction.channel.type !== ChannelType.GuildText
    ) {
      await interaction.reply({
        content: "زر إغلاق التذكرة يعمل داخل قناة التذكرة فقط.",
        ephemeral: true,
      });
      return;
    }

    try {
      if (!(await isTicketParticipant(interaction, interaction.channel))) {
        await interaction.reply({
          content: "ليس لديك صلاحية لإغلاق هذه التذكرة.",
          ephemeral: true,
        });
        return;
      }

      await interaction.reply(createCloseConfirmationMessage());
    } catch (error) {
      console.error("Ticket close confirmation failed.", error);
      await interaction.reply({
        content: "تعذر عرض خيارات إغلاق التذكرة.",
        ephemeral: true,
      });
    }
    return;
  }

  if (
    interaction.isButton() &&
    (interaction.customId === confirmCloseButtonId ||
      interaction.customId === cancelCloseButtonId)
  ) {
    if (
      !interaction.inGuild() ||
      !interaction.channel ||
      interaction.channel.type !== ChannelType.GuildText
    ) {
      await interaction.reply({
        content: "هذا الإجراء متاح داخل قناة التذكرة فقط.",
        ephemeral: true,
      });
      return;
    }

    try {
      if (!(await isTicketParticipant(interaction, interaction.channel))) {
        await interaction.update({
          content: "ليس لديك صلاحية لإدارة هذه التذكرة.",
          components: [],
        });
        return;
      }

      if (interaction.customId === cancelCloseButtonId) {
        await interaction.update({
          content: "تم إلغاء إغلاق التذكرة.",
          components: [],
        });
        return;
      }

      const ownerId = getTicketOwnerId(interaction.channel);

      if (!ownerId) {
        await interaction.update({
          content: "هذه القناة ليست تذكرة صالحة.",
          components: [],
        });
        return;
      }

      await interaction.channel.permissionOverwrites.edit(ownerId, {
        SendMessages: false,
      });
      await interaction.channel.send(
        "🔒 تم إغلاق التذكرة. سيتم حذفها خلال 10 ثوانٍ.",
      );
      await interaction.update({
        content: "تم تأكيد إغلاق التذكرة.",
        components: [],
      });

      setTimeout(() => {
        interaction.channel
          .delete("Support ticket closed.")
          .catch((error) => console.error("Ticket deletion failed.", error));
      }, 10_000);
    } catch (error) {
      console.error("Ticket close action failed.", error);
      if (!interaction.replied && !interaction.deferred) {
        await interaction.reply({
          content: "تعذر إغلاق التذكرة. تحقق من صلاحيات البوت.",
          ephemeral: true,
        });
      }
    }
    return;
  }

  if (interaction.isButton() && interaction.customId === verifyButtonId) {
    if (!interaction.inGuild()) {
      await interaction.reply({
        content: "Verification is only available inside a server.",
        ephemeral: true,
      });
      return;
    }

    await interaction.deferReply({ ephemeral: true });

    try {
      const memberRole = await getOrCreateMemberRole(interaction.guild);
      const member = await interaction.guild.members.fetch(interaction.user.id);

      if (member.roles.cache.has(memberRole.id)) {
        await interaction.editReply(
          "You are already verified and have the MEMBER role.",
        );
        return;
      }

      await member.roles.add(
        memberRole,
        "Member completed server verification.",
      );
      await interaction.editReply(
        "Verification complete. You now have the MEMBER role.",
      );
    } catch (error) {
      console.error("Server verification failed.", error);
      await interaction.editReply(
        "I could not complete verification. Make sure I have the Manage Roles permission and that my role is above MEMBER.",
      );
    }
    return;
  }

  if (!interaction.isChatInputCommand()) {
    return;
  }

  if (interaction.commandName === "games") {
    if (!interaction.inGuild()) {
      await interaction.reply({
        content: "نظام الألعاب متاح داخل السيرفر فقط.",
        ephemeral: true,
      });
      return;
    }

    try {
      const channels = await requireGamesCommandChannel(interaction);

      if (!channels) {
        return;
      }

      await interaction.reply(createGamesPanelMessage());
    } catch (error) {
      console.error("Games panel could not be shown.", error);
      await interaction.reply({
        content: "تعذر فتح لوحة الألعاب. حاول مرة أخرى.",
        ephemeral: true,
      });
    }
    return;
  }

  if (interaction.commandName === "points") {
    if (!interaction.inGuild()) {
      await interaction.reply({
        content: "النقاط متاحة داخل السيرفر فقط.",
        ephemeral: true,
      });
      return;
    }

    try {
      const channels = await requireGamesCommandChannel(interaction);

      if (!channels) {
        return;
      }

      const targetUser =
        interaction.options.getUser("user") ?? interaction.user;
      const score = getGameScore(interaction.guild.id, targetUser.id);

      await interaction.reply(
        `🎮 نقاط ${targetUser.username}: **${score.points}**\n` +
          `🏆 الانتصارات: **${score.wins}**\n` +
          `🎯 المشاركات: **${score.participations}**`,
      );
    } catch (error) {
      console.error("Game points could not be shown.", error);
      await interaction.reply({
        content: "تعذر عرض النقاط. حاول مرة أخرى.",
        ephemeral: true,
      });
    }
    return;
  }

  if (interaction.commandName === "leaderboard") {
    if (!interaction.inGuild()) {
      await interaction.reply({
        content: "لوحة المتصدرين متاحة داخل السيرفر فقط.",
        ephemeral: true,
      });
      return;
    }

    try {
      const channels = await requireGamesCommandChannel(interaction);

      if (!channels) {
        return;
      }

      const guildPrefix = `${interaction.guild.id}:`;
      const leaderboard = Array.from(gameScores.entries())
        .filter(([key]) => key.startsWith(guildPrefix))
        .sort(([, first], [, second]) => second.points - first.points)
        .slice(0, 10);

      const description =
        leaderboard.length === 0
          ? "لا توجد نتائج بعد. ابدأ أول لعبة من لوحة `/games`."
          : leaderboard
              .map(([key, score], index) => {
                const userId = key.slice(guildPrefix.length);
                return `${index + 1}. <@${userId}> — **${score.points} نقطة** (${score.wins} فوز)`;
              })
              .join("\n");

      await interaction.reply({
        embeds: [
          new EmbedBuilder()
            .setColor(0xffd700)
            .setTitle("🏆 أفضل لاعبي ألعاب 911")
            .setDescription(description)
            .setFooter({ text: "الفوز +10 • المشاركة +2" }),
        ],
      });
    } catch (error) {
      console.error("Game leaderboard could not be shown.", error);
      await interaction.reply({
        content: "تعذر عرض لوحة المتصدرين. حاول مرة أخرى.",
        ephemeral: true,
      });
    }
    return;
  }

  if (interaction.commandName === "warn") {
    if (!interaction.inGuild()) {
      await interaction.reply({
        content: "نظام التحذيرات متاح داخل السيرفر فقط.",
        ephemeral: true,
      });
      return;
    }

    if (
      !interaction.memberPermissions?.has(
        PermissionsBitField.Flags.ModerateMembers,
      )
    ) {
      await interaction.reply({
        content: "❌ ما عندك صلاحية تعطي تحذير.",
        ephemeral: true,
      });
      return;
    }

    const member = interaction.options.getMember("member");
    const reason = interaction.options.getString("reason")?.trim();

    if (!member) {
      await interaction.reply({
        content: "❌ العضو غير موجود.",
        ephemeral: true,
      });
      return;
    }

    if (member.id === interaction.user.id) {
      await interaction.reply({
        content: "❌ ما تگدر تحذر نفسك.",
        ephemeral: true,
      });
      return;
    }

    if (!member.manageable) {
      await interaction.reply({
        content: "❌ لا يمكن للبوت تحذير هذا العضو بسبب ترتيب الرتب.",
        ephemeral: true,
      });
      return;
    }

    try {
      const { warnRole, logChannel } = await setupWarnSystem(
        interaction.guild,
      );
      await assertRoleIsBelowBot(interaction.guild, warnRole, "the WARN role");

      if (!member.roles.cache.has(warnRole.id)) {
        await member.roles.add(warnRole, `Warning: ${reason}`);
      }

      const key = warningKey(interaction.guild.id, member.id);
      const userWarnings = warnings.get(key) ?? [];
      userWarnings.push({
        moderator: interaction.user.id,
        reason,
        date: new Date().toISOString(),
      });
      warnings.set(key, userWarnings);
      saveWarnings();

      const warnNumber = userWarnings.length;
      const embed = new EmbedBuilder()
        .setColor(0xff0000)
        .setTitle("⚠️・𝑾𝑨𝑹𝑵")
        .addFields(
          {
            name: "👤 العضو",
            value: `${member}`,
            inline: true,
          },
          {
            name: "🛡️ المشرف",
            value: `${interaction.user}`,
            inline: true,
          },
          {
            name: "🔢 عدد التحذيرات",
            value: `${warnNumber}`,
            inline: true,
          },
          {
            name: "📝 السبب",
            value: reason,
          },
        )
        .setTimestamp();

      try {
        await logChannel.send({ embeds: [embed] });
      } catch (error) {
        console.error("Warn log message could not be sent.", error);
      }

      await interaction.reply(
        `⚠️ تم تحذير ${member}\n` +
          `📝 السبب: **${reason}**\n` +
          `🔢 عدد التحذيرات: **${warnNumber}**`,
      );
    } catch (error) {
      console.error("Warn command failed.", error);
      await interaction.reply({
        content: "❌ تعذر تنفيذ التحذير. تأكد من صلاحيات البوت وترتيب الرتب.",
        ephemeral: true,
      });
    }
    return;
  }

  if (interaction.commandName === "warnings") {
    if (!interaction.inGuild()) {
      await interaction.reply({
        content: "سجل التحذيرات متاح داخل السيرفر فقط.",
        ephemeral: true,
      });
      return;
    }

    const member = interaction.options.getMember("member");

    if (!member) {
      await interaction.reply({
        content: "❌ العضو غير موجود.",
        ephemeral: true,
      });
      return;
    }

    const userWarnings = warnings.get(
      warningKey(interaction.guild.id, member.id),
    ) ?? [];

    if (userWarnings.length === 0) {
      await interaction.reply({
        content: `✅ ${member} ما عليه أي تحذيرات.`,
        ephemeral: true,
      });
      return;
    }

    const list = userWarnings
      .map(
        (warning, index) =>
          `**${index + 1}.** ${warning.reason.slice(0, 300)}`,
      )
      .join("\n");

    const embed = new EmbedBuilder()
      .setColor(0xff0000)
      .setTitle("⚠️・سجل التحذيرات")
      .setDescription(`👤 العضو: ${member}\n\n${list}`)
      .setFooter({
        text: `911 WARN SYSTEM • ${userWarnings.length} تحذير`,
      });

    await interaction.reply({ embeds: [embed] });
    return;
  }

  if (interaction.commandName === "clearwarn") {
    if (!interaction.inGuild()) {
      await interaction.reply({
        content: "نظام التحذيرات متاح داخل السيرفر فقط.",
        ephemeral: true,
      });
      return;
    }

    if (
      !interaction.memberPermissions?.has(
        PermissionsBitField.Flags.ModerateMembers,
      )
    ) {
      await interaction.reply({
        content: "❌ ما عندك صلاحية.",
        ephemeral: true,
      });
      return;
    }

    const member = interaction.options.getMember("member");

    if (!member) {
      await interaction.reply({
        content: "❌ العضو غير موجود.",
        ephemeral: true,
      });
      return;
    }

    try {
      warnings.delete(warningKey(interaction.guild.id, member.id));
      saveWarnings();

      const warnRole = interaction.guild.roles.cache.find(
        (role) => role.name === WARN_ROLE_NAME,
      );

      if (warnRole && member.roles.cache.has(warnRole.id)) {
        await member.roles.remove(warnRole, "All warnings cleared.");
      }

      await interaction.reply({
        content: `✅ تم مسح جميع تحذيرات ${member}.`,
      });
    } catch (error) {
      console.error("Clear warning command failed.", error);
      await interaction.reply({
        content: "❌ تعذر مسح التحذيرات. تأكد من صلاحيات البوت وترتيب الرتب.",
        ephemeral: true,
      });
    }
    return;
  }

  if (interaction.commandName === "setup-ticket") {
    if (!interaction.inGuild()) {
      await interaction.reply({
        content: "إعداد التذاكر متاح فقط داخل السيرفر.",
        ephemeral: true,
      });
      return;
    }

    await interaction.deferReply({ ephemeral: true });

    try {
      await assertBotHasTicketPermissions(interaction.guild);
      const memberRole = await getOrCreateMemberRole(interaction.guild);
      await assertMemberRoleIsAssignable(interaction.guild, memberRole);
      const staffRole = await getOrCreateStaffRole(interaction.guild);
      const departmentRoles = await getOrCreateDepartmentRoles(
        interaction.guild,
      );
      await assertRoleIsBelowBot(
        interaction.guild,
        staffRole,
        "the STAFF role",
      );
      for (const definition of departmentRoleDefinitions) {
        await assertRoleIsBelowBot(
          interaction.guild,
          departmentRoles[definition.key],
          `${definition.label} role`,
        );
      }
      const ticketPanelChannel = await getOrCreateTicketPanelChannel(
        interaction.guild,
      );

      await ticketPanelChannel.send(createTicketPanelMessage());
      await interaction.editReply(
        `تم إعداد لوحة التذاكر في <#${ticketPanelChannel.id}> 🎫`,
      );
    } catch (error) {
      console.error("Ticket setup failed.", error);
      await interaction.editReply(
        "تعذر إعداد نظام التذاكر. تأكد من الصلاحيات وأن رتب STAFF والأقسام و MEMBER تحت رتبة البوت.",
      );
    }
    return;
  }

  if (interaction.commandName === "setup-verify") {
    if (!interaction.inGuild()) {
      await interaction.reply({
        content: "The verification setup command can only be used in a server.",
        ephemeral: true,
      });
      return;
    }

    try {
      await getOrCreateMemberRole(interaction.guild);
      await interaction.reply(createVerificationMessage());
    } catch (error) {
      console.error("Verification setup failed.", error);
      await interaction.reply({
        content:
          "I could not set up verification. Make sure I have the Manage Roles permission.",
        ephemeral: true,
      });
    }
    return;
  }

  if (interaction.commandName === "ping") {
    await interaction.reply(`Pong! Gateway latency: ${client.ws.ping}ms.`);
    return;
  }

  if (interaction.commandName === "help") {
    await interaction.reply({
      content:
        "**911-bot commands**\n`/ping` — check connectivity\n`/status` — view uptime and connection status\n`/setup-verify` — post the verification panel\n`/setup-ticket` — post the support ticket panel\n`/games` — open the Discord games panel\n`/points` — show game points\n`/leaderboard` — show the top game players\n`/warn` — warn a member\n`/warnings` — view a member's warnings\n`/clearwarn` — clear a member's warnings\n`/help` — show this message",
      ephemeral: true,
    });
    return;
  }

  if (interaction.commandName === "status") {
    const uptimeSeconds = Math.floor((client.uptime ?? 0) / 1000);
    const hours = Math.floor(uptimeSeconds / 3600);
    const minutes = Math.floor((uptimeSeconds % 3600) / 60);
    const seconds = uptimeSeconds % 60;

    await interaction.reply(
      `Online. Uptime: ${hours}h ${minutes}m ${seconds}s. Gateway latency: ${client.ws.ping}ms.`,
    );
  }
});

client.on(Events.GuildMemberAdd, async (member) => {
  try {
    const memberRole = await getOrCreateMemberRole(member.guild);
    await assertMemberRoleIsAssignable(member.guild, memberRole);

    if (!member.roles.cache.has(memberRole.id)) {
      await member.roles.add(
        memberRole,
        "Automatically assigned on server join.",
      );
      console.info(
        `Assigned ${memberRoleName} to ${member.user.tag} in ${member.guild.name}.`,
      );
    } else {
      console.info(
        `${member.user.tag} already has ${memberRoleName} in ${member.guild.name}.`,
      );
    }
  } catch (error) {
    console.error(
      `Automatic MEMBER role assignment failed for ${member.user.tag}.`,
      error,
    );
  }

  try {
    const welcomeSent = await sendWelcomeMessage(member);

    if (welcomeSent) {
      console.info(
        `Sent a welcome message for ${member.user.tag} in ${member.guild.name}.`,
      );
    }
  } catch (error) {
    console.error(
      `Welcome message failed for ${member.user.tag}. Make sure the bot can view and send messages in ${WELCOME_CHANNEL_NAME}.`,
      error,
    );
  }
});

client.on(Events.Error, (error) => {
  console.error("Discord client error.", error);
});

client.on("shardError", (error) => {
  console.error("❌ Discord shard error.", error);
});

process.on("uncaughtException", (error) => {
  console.error("🚨 Uncaught exception.", error);
});

process.on("unhandledRejection", (error) => {
  console.error("🚨 Unhandled promise rejection.", error);
});

function shutdown(signal) {
  console.info(`Received ${signal}; shutting down 911-bot.`);
  client.destroy();
  server.close(() => process.exit(0));
}

process.on("SIGINT", () => shutdown("SIGINT"));
process.on("SIGTERM", () => shutdown("SIGTERM"));

async function startBot() {
  try {
    console.info("🔄 Attempting to connect 911-bot to Discord...");
    await client.login(token);
    console.info("✅ 911-bot login completed.");
  } catch (error) {
    console.error("❌ Discord login failed.", error);
    console.info("🔄 Retrying Discord login in 10 seconds...");
    setTimeout(startBot, 10_000);
  }
}

startBot();