# 911-bot

911-bot is a Node.js Discord bot with lightweight slash commands for connectivity and runtime status.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- `pnpm --filter @workspace/911-bot run dev` — run the Discord bot
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `services/911-bot/src/index.mjs` — Discord client, slash command registration, and command handlers
- `services/911-bot/README.md` — setup and invite instructions

## Architecture decisions

- The bot uses Discord slash commands rather than message-content commands, so it only needs the Guilds gateway intent.
- Commands are registered globally on startup to keep the starter project portable across servers.
- The bot token is read from the `DISCORD_BOT_TOKEN` secret and is never stored in source control.

## Product

The bot provides `/ping`, `/status`, and `/help` commands for verifying that a Discord bot deployment is connected and healthy.

## User preferences

No additional preferences specified.

## Gotchas

- Global slash command registration can take a short time to propagate in Discord.
- This bot is a starter utility and is not connected to emergency dispatch services.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
